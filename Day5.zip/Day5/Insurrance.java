package Day5;

import java.util.Date;

public class Insurrance {
	
	private String tenGoiBaoHiem;
	private String thoiHanDong;
	private String mucPhiDong;
	private String mucDich;
	private String cachThucDong;
	private Date thoiGianBatDau;
	private String soCMND;
	private int insType;
	public Insurrance() {
	}

	

	public Insurrance(String hoTen, Date ngaySinh, String noiThuongTru, String soCMND, String tenGoiBaoHiem,
			String thoiHanDong, String mucPhiDong, String mucDich, String cachThucDong, Date thoiGianBatDau,
			int insType) {
		super();
		this.soCMND = soCMND;
		this.tenGoiBaoHiem = tenGoiBaoHiem;
		this.thoiHanDong = thoiHanDong;
		this.mucPhiDong = mucPhiDong;
		this.mucDich = mucDich;
		this.cachThucDong = cachThucDong;
		this.thoiGianBatDau = thoiGianBatDau;
		this.insType = insType;
	}



	public String getTenGoiBaoHiem() {
		return tenGoiBaoHiem;
	}

	public void setTenGoiBaoHiem(String tenGoiBaoHiem) {
		this.tenGoiBaoHiem = tenGoiBaoHiem;
	}

	public String getThoiHanDong() {
		return thoiHanDong;
	}

	public void setThoiHanDong(String thoiHanDong) {
		this.thoiHanDong = thoiHanDong;
	}

	public int getInsType() {
		return insType;
	}

	public void setInsType(int insType) {
		this.insType = insType;
	}

	public String getMucPhiDong() {
		return mucPhiDong;
	}

	public void setMucPhiDong(String mucPhiDong) {
		this.mucPhiDong = mucPhiDong;
	}

	public String getMucDich() {
		return mucDich;
	}

	public void setMucDich(String mucDich) {
		this.mucDich = mucDich;
	}

	public String getCachThucDong() {
		return cachThucDong;
	}

	public void setCachThucDong(String cachThucDong) {
		this.cachThucDong = cachThucDong;
	}

	

	public Date getThoiGianBatDau() {
		return thoiGianBatDau;
	}



	public void setThoiGianBatDau(Date thoiGianBatDau) {
		this.thoiGianBatDau = thoiGianBatDau;
	}


	public String getSoCMND() {
		return soCMND;
	}

	public void setSoCMND(String soCMND) {
		this.soCMND = soCMND;
	}

	@Override
	public String toString() {
		return "Ten Goi Bao Hiem: " + tenGoiBaoHiem + ", \nThoi Han Dong: "
				+ thoiHanDong + ", \nMuc Phi Dong: " + mucPhiDong + ", \nMuc Dich: " + mucDich + ", \nCach Thuc Dong: "
				+ cachThucDong + ", \nThoiGianBatDau: " + thoiGianBatDau + "";
	}

}