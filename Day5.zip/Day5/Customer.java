package Day5;

import java.util.Date;

public class Customer {
	private String hoTen;
	private Date ngaySinh;
	private String noiThuongTru;
	private String soCMND;
	private Insurrance ins;
	
	public Insurrance getIns() {
		return ins;
	}

	public void setIns(Insurrance ins) {
		this.ins = ins;
	}

	public Customer() {
	}

	

	public Customer(String hoTen, Date ngaySinh, String noiThuongTru, String soCMND, Insurrance ins) {
		super();
		this.hoTen = hoTen;
		this.ngaySinh = ngaySinh;
		this.noiThuongTru = noiThuongTru;
		this.soCMND = soCMND;
		this.ins = ins;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public Date getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	public String getNoiThuongTru() {
		return noiThuongTru;
	}

	public void setNoiThuongTru(String noiThuongTru) {
		this.noiThuongTru = noiThuongTru;
	}

	public String getSoCMND() {
		return soCMND;
	}

	public void setSoCMND(String soCMND) {
		this.soCMND = soCMND;
	}

	@Override
	public String toString() {
		 String s ="hoTen: " + hoTen + ", \nngaySinh: " + ngaySinh + ", \nnoiThuongTru: " + noiThuongTru + ", \nsoCMND"
				+ soCMND + "";
		 return s;
	}

}