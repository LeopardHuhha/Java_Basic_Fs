package Day5;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import Day5.DataAccess;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 
 * @author HCD-Fresher017
 *
 */
public class InsurranceManagement {
	Customer cm = new Customer();
	static Scanner scan = new Scanner(System.in);
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	DataAccess da = new DataAccess();
	Connection con =da.getConnect();
	
	public static void main(String[] args) throws ParseException {
		
		InsurranceManagement insmng = new InsurranceManagement();
		
		ArrayList<Customer> arr = new ArrayList<>();
		int insType = 0;
		insmng.outputIns();
		do {
			System.out.println("Goi bao hiem");
			System.out.println("--Bao hiem tu vong = 0");
			System.out.println("--Bao hiem sinh ky =1");
			System.out.println("--Bao hiem thoi han hop dong =2");
			insType = inputVl();

		} while (insType < 0 || insType > 2);
		switch (insType) {
		case 0:
			insmng.inputDeathInsurrance();
			break;
		case 1:
			insmng.inputLifeInsurrance();
			break;
		case 2:
			insmng.inputContractInsurrance();
			break;
		}
		
		
	}

	public static int inputVl() {
		int insType = 0;
		boolean type = false;
		while (type == false) {
			System.out.println("Xin moi chon:");
			try {
				insType = scan.nextInt();
				type = true;
			} catch (Exception e) {
				System.out.println("Moi nhap lai");
				scan.nextLine();
			}
		}
		return insType;
	}

	public void inputInsurrance(Insurrance ins,Customer cm) throws ParseException {
		scan.nextLine();
		System.out.println("Nhap ho ten: ");
		cm.setHoTen(scan.nextLine());
		System.out.println("Nhap ngay sinh");
		cm.setNgaySinh(formatter.parse(scan.nextLine()));
		System.out.println("Noi thuong tru: ");
		cm.setNoiThuongTru(scan.nextLine());
		System.out.println("So CMND: ");
		cm.setSoCMND(scan.nextLine());
		System.out.println("Thoi han: ");
		ins.setThoiHanDong(scan.nextLine());
		System.out.println("Muc phi dong: ");
		ins.setMucPhiDong(scan.nextLine());
		System.out.println("Muc dich: ");
		ins.setMucDich(scan.nextLine());
		System.out.println("Cach thuc dong: ");
		ins.setCachThucDong(scan.nextLine());
		System.out.println("Thoi gian bat dau: ");
		ins.setThoiGianBatDau(formatter.parse(scan.nextLine()));
	}

	public void inputDeathInsurrance() throws ParseException {
		Customer cm = new Customer();
		Insurrance ins = new DeathInsurrance();
		inputInsurrance(ins,cm);
		ins.setInsType(0);
		ins.setTenGoiBaoHiem("Bao hiem tu vong");
		System.out.println("Truong hop dong bao hiem: ");
		((DeathInsurrance) ins).setTruongHopDongBaoHiem(scan.nextLine());
		System.out.println("Thoi gian toi thieu tham gia: ");
		((DeathInsurrance) ins).setThoiGianToiThieuThamGia(scan.nextLine());
		System.out.println(((DeathInsurrance) ins).toString());
		addInsurrance1((DeathInsurrance) ins, cm);
	}

	public void inputLifeInsurrance() throws ParseException {
		Customer cm = new Customer();
		Insurrance ins = new LifeInsurrance();
		inputInsurrance(ins,cm);
		ins.setInsType(1);
		ins.setTenGoiBaoHiem("Bao hiem sinh ky");
		System.out.println("Thoi gian ket thuc: ");
		((LifeInsurrance) ins).setThoiGianKetThuc(formatter.parse(scan.nextLine()));
		System.out.println("Thoi gian tro cap: ");
		((LifeInsurrance) ins).setThoiGianTroCap(scan.nextLine());
		System.out.println(((LifeInsurrance) ins).toString());
		addInsurrance2((LifeInsurrance) ins,cm);
	}

	public void inputContractInsurrance() throws ParseException {
		Customer cm = new Customer();
		Insurrance ins = new ContractInsurrance();
		inputInsurrance(ins,cm);
		ins.setInsType(2);
		ins.setTenGoiBaoHiem("Bao hiem hop dong");
		System.out.println("Thoi gian ket thuc: ");
		((ContractInsurrance) ins).setThoiGianKetThuc(formatter.parse(scan.nextLine()));
		System.out.println("San pham di kem: ");
		((ContractInsurrance) ins).setSanPhamDiKem(scan.nextLine());
		System.out.println(((ContractInsurrance) ins).toString());
		addInsurrance3((ContractInsurrance) ins, cm);
	}
	
	public void addInsurrance1(DeathInsurrance dins, Customer cm){
		//DataAccess da=new DataAccess();
		//Connection con =da.getConnect();
		PreparedStatement pstm = null;
		
		String sql = "INSERT INTO CUSTOMER(hoten,ngaysinh,noithuongtru,soCMND)"+"VALUES(?,?,?,?)";
		try {
			pstm = con.prepareStatement(sql);
			pstm.setString(1, cm.getHoTen());
			pstm.setDate(2, new java.sql.Date(cm.getNgaySinh().getTime()));
			pstm.setString(3, cm.getNoiThuongTru());
			pstm.setString(4, cm.getSoCMND());
			pstm.executeUpdate();
		}
		catch (SQLException e) {
			e.printStackTrace();
	}
		String sql1 = "INSERT INTO INSURRANCE(tengoiBH,thoihandong,mucphidong,mucdich"
				+ ",cachthucdong,thoigianbatdau,truonghopBH,thoigiantoithieuthamgia,soCMND)"+"VALUES(?,?,?,?,?,?,?,?,?)";

		try{
		pstm = con.prepareStatement(sql1);
		pstm.setString(1, dins.getTenGoiBaoHiem());
		pstm.setString(2, dins.getThoiHanDong());
		pstm.setString(3, dins.getMucPhiDong());
		pstm.setString(4, dins.getMucDich());
		pstm.setString(5, dins.getCachThucDong());
		pstm.setDate(6, new java.sql.Date(dins.getThoiGianBatDau().getTime()));
		pstm.setString(7, dins.getTruongHopDongBaoHiem());
		pstm.setString(8, dins.getThoiGianToiThieuThamGia());
		pstm.setString(9, cm.getSoCMND());
		pstm.executeUpdate();
	}
	catch (SQLException e) {
		e.printStackTrace();
	}
	}

		public void addInsurrance2(LifeInsurrance lins,Customer cm){
			//DataAccess da=new DataAccess();
			//Connection con =da.getConnect();
			PreparedStatement pstm = null;
			String sql = "INSERT INTO CUSTOMER(hoten,ngaysinh,noithuongtru,soCMND)"+"VALUES(?,?,?,?)";
			try {
				pstm = con.prepareStatement(sql);
				pstm.setString(1, cm.getHoTen());
				pstm.setDate(2, new java.sql.Date(cm.getNgaySinh().getTime()));
				pstm.setString(3, cm.getNoiThuongTru());
				pstm.setString(4, cm.getSoCMND());
				pstm.executeUpdate();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
				
			String sql1 = "INSERT INTO INSURRANCE(tengoiBH,thoihandong,mucphidong,mucdich,"
					+ "cachthucdong,thoigianbatdau,thoigianketthuc,thoigiantrocap,soCMND)"+"VALUES(?,?,?,?,?,?,?,?,?)";
			try {
				pstm = con.prepareStatement(sql1);
				pstm.setString(1, lins.getTenGoiBaoHiem());
				pstm.setString(2, lins.getThoiHanDong());
				pstm.setString(3, lins.getMucPhiDong());
				pstm.setString(4, lins.getMucDich());
				pstm.setString(5, lins.getCachThucDong());
				pstm.setDate(6, new java.sql.Date(lins.getThoiGianBatDau().getTime()));
				pstm.setDate(7, new java.sql.Date(lins.getThoiGianKetThuc().getTime()));
				pstm.setString(8, lins.getThoiGianTroCap());
				pstm.setString(9, cm.getSoCMND());
				pstm.executeUpdate();
			}
			catch (SQLException e) {
				e.printStackTrace();
		}
			}
	
		public void addInsurrance3(ContractInsurrance cins, Customer cm){
			//DataAccess da=new DataAccess();
			//Connection con =da.getConnect();
			PreparedStatement pstm = null;
			String sql = "INSERT INTO CUSTOMER(hoten,ngaysinh,noithuongtru,soCMND)"+"VALUES(?,?,?,?)";
			try {
				pstm = con.prepareStatement(sql);
				pstm.setString(1, cm.getHoTen());
				pstm.setDate(2, new java.sql.Date(cm.getNgaySinh().getTime()));
				pstm.setString(3, cm.getNoiThuongTru());
				pstm.setString(4, cm.getSoCMND());
				pstm.executeUpdate();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			
			String sql1 = "INSERT INTO INSURRANCE(tengoiBH,thoihandong,mucphidong,mucdich,"
					+ "cachthucdong,thoigianbatdau,thoigianketthuc,sanphamdikem,soCMND)"+"VALUES(?,?,?,?,?,?,?,?,?)";
			try {
				pstm = con.prepareStatement(sql1);
				pstm.setString(1, cins.getTenGoiBaoHiem());
				pstm.setString(2, cins.getThoiHanDong());
				pstm.setString(3, cins.getMucPhiDong());
				pstm.setString(4, cins.getMucDich());
				pstm.setString(5, cins.getCachThucDong());
				pstm.setDate(6, new java.sql.Date(cins.getThoiGianBatDau().getTime()));
				pstm.setDate(7, new java.sql.Date(cins.getThoiGianKetThuc().getTime()));
				pstm.setString(8, cins.getSanPhamDiKem());
				pstm.setString(9, cm.getSoCMND());
				pstm.executeUpdate();
			}
			catch (SQLException e) {
				e.printStackTrace();
		}
			
}
		public ArrayList<Customer> getList(){
			ArrayList<Customer> listkh = new ArrayList<>();
			//DataAccess da=new DataAccess();
			try {
			String sql = "SELECT* FROM CUSTOMER JOIN INSURRANCE ON CUSTOMER.soCMND=INSURRANCE.soCMND";
			ResultSet rs = null;
			Statement stmt = da.getConnect().createStatement();
			rs = stmt.executeQuery(sql);
			Customer cm;
			Insurrance ins = null;
			while(rs.next()){
				cm = new Customer();
				cm.setHoTen(rs.getString("hoten"));
				cm.setNgaySinh(rs.getDate("ngaysinh"));
				cm.setNoiThuongTru(rs.getString("noithuongtru"));
				cm.setSoCMND(rs.getString("soCMND"));
				if(rs.getString("tengoiBH").equals("Bao hiem tu vong")){
					ins =new DeathInsurrance();
					((DeathInsurrance)ins).setTenGoiBaoHiem(rs.getString("tengoiBH"));
					((DeathInsurrance)ins).setThoiHanDong(rs.getString("thoihandong"));
					((DeathInsurrance)ins).setMucPhiDong(rs.getString("mucphidong"));
					((DeathInsurrance)ins).setMucDich(rs.getString("mucdich"));
					((DeathInsurrance)ins).setCachThucDong(rs.getString("cachthucdong"));
					((DeathInsurrance)ins).setThoiGianBatDau(rs.getDate("thoigianbatdau"));
					((DeathInsurrance)ins).setTruongHopDongBaoHiem(rs.getString("truonghopBH"));
					((DeathInsurrance)ins).setThoiGianToiThieuThamGia(rs.getString("thoigiantoithieuthamgia"));
				}
				
				if(rs.getString("tengoiBH").equals("Bao hiem sinh ky")){
					ins =new LifeInsurrance();
					((LifeInsurrance)ins).setTenGoiBaoHiem(rs.getString("tengoiBH"));
					((LifeInsurrance)ins).setThoiHanDong(rs.getString("thoihandong"));
					((LifeInsurrance)ins).setMucPhiDong(rs.getString("mucphidong"));
					((LifeInsurrance)ins).setMucDich(rs.getString("mucdich"));
					((LifeInsurrance)ins).setCachThucDong(rs.getString("cachthucdong"));
					((LifeInsurrance)ins).setThoiGianBatDau(rs.getDate("thoigianbatdau"));
					((LifeInsurrance)ins).setThoiGianKetThuc(rs.getDate("thoigianketthuc"));
					((LifeInsurrance)ins).setThoiGianTroCap(rs.getString("thoigiantrocap"));
				}
				if(rs.getString("tengoiBH").equals("Bao hiem hop dong")){
					ins = new ContractInsurrance();
					((ContractInsurrance)ins).setTenGoiBaoHiem(rs.getString("tengoiBH"));
					((ContractInsurrance)ins).setThoiHanDong(rs.getString("thoihandong"));
					((ContractInsurrance)ins).setMucPhiDong(rs.getString("mucphidong"));
					((ContractInsurrance)ins).setMucDich(rs.getString("mucdich"));
					((ContractInsurrance)ins).setCachThucDong(rs.getString("cachthucdong"));
					((ContractInsurrance)ins).setThoiGianBatDau(rs.getDate("thoigianbatdau"));
					((ContractInsurrance)ins).setThoiGianKetThuc(rs.getDate("thoigianketthuc"));
					((ContractInsurrance)ins).setSanPhamDiKem(rs.getString("sanphamdikem"));
				}
				cm.setIns(ins);
				listkh.add(cm);
			}
			
			} catch (Exception e) {
				e.printStackTrace();
			}
			return listkh;
		}
public void outputIns(){			
			ArrayList<Customer> arr = getList();
			for (Customer cm : arr) {
				System.out.println("Ho Ten: "+cm.getHoTen());
				System.out.println("Ngay sinh: "+cm.getNgaySinh());
				System.out.println("Noi thuong tru: "+cm.getNoiThuongTru());
				System.out.println("So CMND: "+cm.getSoCMND());
				if(cm.getIns() instanceof DeathInsurrance){
					DeathInsurrance dins = (DeathInsurrance) cm.getIns();
				System.out.println("Ten goi BH: "+dins.getTenGoiBaoHiem());
				System.out.println("Thoi han dong: "+dins.getThoiHanDong());
				System.out.println("Muc phi dong: "+dins.getMucPhiDong());
				System.out.println("Muc dich: "+dins.getMucDich());
				System.out.println("Cach thuc dong: "+dins.getCachThucDong());
				System.out.println("Thoi gian bat dau: "+dins.getThoiGianBatDau());
				System.out.println("Thoi gian ket thuc: "+null);
				System.out.println("San pham di kem: "+null);
				System.out.println("Loai BH: "+dins.getTruongHopDongBaoHiem());
				System.out.println("Thoi gian toi thieu tham gia: "+dins.getThoiGianToiThieuThamGia());
				System.out.println("Thoi gian tro cap: "+null);
				System.out.println("====================================================");
				}
				if(cm.getIns() instanceof LifeInsurrance){
					LifeInsurrance lins = (LifeInsurrance) cm.getIns();
				System.out.println("Ten goi BH: "+lins.getTenGoiBaoHiem());
				System.out.println("Thoi han dong: "+lins.getThoiHanDong());
				System.out.println("Muc phi dong: "+lins.getMucPhiDong());
				System.out.println("Muc dich: "+lins.getMucDich());
				System.out.println("Cach thuc dong: "+lins.getCachThucDong());
				System.out.println("Thoi gian bat dau: "+lins.getThoiGianBatDau());
				System.out.println("Thoi gian ket thuc: "+lins.getThoiGianKetThuc());
				System.out.println("San pham di kem: "+null);
				System.out.println("Loai BH: "+null);
				System.out.println("Thoi gian toi thieu tham gia: "+null);
				System.out.println("Thoi gian tro cap: "+lins.getThoiGianTroCap());
				System.out.println("====================================================");
				}
				if(cm.getIns() instanceof ContractInsurrance){
					ContractInsurrance cins = (ContractInsurrance) cm.getIns();
				System.out.println("Ten goi BH: "+cins.getTenGoiBaoHiem());
				System.out.println("Thoi han dong: "+cins.getThoiHanDong());
				System.out.println("Muc phi dong: "+cins.getMucPhiDong());
				System.out.println("Muc dich: "+cins.getMucDich());
				System.out.println("Cach thuc dong: "+cins.getCachThucDong());
				System.out.println("Thoi gian bat dau: "+cins.getThoiGianBatDau());
				System.out.println("Thoi gian ket thuc: "+cins.getThoiGianKetThuc());
				System.out.println("San pham di kem: "+cins.getSanPhamDiKem());
				System.out.println("Loai BH: " +null);
				System.out.println("Thoi gian toi thieu tham gia: "+null);
				System.out.println("Thoi gian tro cap: "+null);
				System.out.println("====================================================");
			}
				}
		}

		}